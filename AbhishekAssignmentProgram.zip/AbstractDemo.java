package javatraining;

abstract class Person
{
	abstract void walk();
	
	public void eat()
	{
		System.out.println("Ice");
	}
	Person()
	{
		System.out.println("Person are Wartching TV");
	}
	
}

public class AbstractDemo extends Person
{
	 void walk()
		{
			System.out.println("Man Are Walk Slowly");
		}
		
	public static void main(String args[])
	{
	AbstractDemo AD=new AbstractDemo();
	AD.walk();
	AD.eat();
		
	}
}
