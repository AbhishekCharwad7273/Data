package javatraining;

abstract class Emp
{
	public static int numberOfLegs=2;
	abstract public void walk();
	public static void eat()
{
	System.out.println("Eating pizza");
}
}
	public class AbstractStatic
{
	public static void main(String args[])
{
	System.out.println("Number of Legs="+Emp.numberOfLegs);
	Emp.eat();
}
}

