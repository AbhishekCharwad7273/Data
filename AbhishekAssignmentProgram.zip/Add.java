package javatraining;

import java.io.*;
import java.util.Scanner;
public class Add 
{

		 public void add()
		 {
			 Scanner sc=new Scanner(System.in);
			 System.out.println("enter the first number");
			 int a=sc.nextInt();
			 System.out.println("enter the Second number");
			 int b=sc.nextInt();
			 int result=a+b;
			 System.out.println("result are:="+result);
		 }
		 public static void main(String args[]) // ->method prototype.
		 { 
		 
			 Add obj= new Add();
			 obj.add();
		 }
}

