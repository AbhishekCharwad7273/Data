package javatraining;
import java.util.*;
public class AnonymousObject
{
	
		Scanner sc=new Scanner(System.in);
		
		int iNo=sc.nextInt();
		
		int fact=1;
		void factorial()
		{
			for (int i=1;i<=iNo;i++)
			{
				fact=fact*i;
			}
			System.out.println("Factorial is="+fact);
		}
		
		public static void main(String args[])
		{
			new AnonymousObject().factorial();
	}
}
