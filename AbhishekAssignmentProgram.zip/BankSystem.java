package javatraining;

import java.util.*;

class Account
{
	String name;
	int  acc_no;
	float amount;
	
	
	
	void insert(int a,String n,float amt)
	{
		acc_no=a;
		name=n;
		amount=amt;
		
	}
	
	void deposit(float amt)
	{
		amount=amount+amt;
		System.out.println("After Deposit Amount will be"+amount);
		
	}
	
	void withdraw(float amt)
	{
		if(amount<amt)
		{
			System.out.println("insufficiant Balance");
		}
		
		else 
		{
			amount=amount-amt;
			System.out.println("After Withdraw Amt will be"+amount);
			
		}
		
	}
	
	void checkBal()
	{
			System.out.println("Balance is:"+amount);
	}
	
	void display()
	{
		System.out.println(acc_no+" "+name+" "+amount);
	}
	
}






public class BankSystem 
{
	public static void main(String args[])
	{
		Account a1=new Account (); 
		a1. insert(832345,"Ankit",1000); 
		a1. display (); 
		a1. checkBal(); 
		a1. deposit (40000); 
		a1. checkBal(); 
		a1. withdraw (15000); 
		a1. checkBal();
		
	}
}
