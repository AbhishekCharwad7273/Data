package javatraining;


class Bird
{
	private String name;
	private String clr;
	private String swim;
	private String AvgLifeTime;
	private String weight;
	
	
	
	public String getname()
	{
		return name;
		
	}
	
	public void setname(String name)
	{
		this.name=name;
	}
	
	public String getclr()
	{
		return clr;
	}
	
	public void setclr(String clr)
	{
		this.clr=clr;
	}
	
	public String getAvgLifeTime()
	{
		return AvgLifeTime;
	}
	public void setAvgLifeTime(String AvgLifeTime)
	{
		this.AvgLifeTime=AvgLifeTime;
	}
	
	public String getweight()
	{
		return weight;
		
	}
	
	public void setweight(String weight)
	{
		this.weight=weight;
	}
	
	public String getswim()
	{
		return swim;
		
	}
	
	public void setswim(String swim)
	{
		this.swim=swim;
	}
	
	public void fly(String string)
	{
		System.out.println(string);
	}
	public void walk(String string)
	{
		System.out.println(string);
	}

	
	
}





public class BirdInfo 
{
	public static void displayBirdInformation(Bird bird)
	{
		System.out.println("Name : "+ bird.getname());
		System.out.println("Color : "+bird.getclr());
		System.out.println("Can Swim : "+bird.getswim());
		System.out.println("Avg Life time : "+bird.getAvgLifeTime());
		System.out.println("Weight : "+bird.getweight());
	}
	
	
	
	public static void main(String args[])
	{
	
		
		 Bird sparrowBird=new Bird();
		 sparrowBird.setname("Sprrow");
		 sparrowBird.setclr("Gold");
		 sparrowBird.setswim("No");
		 sparrowBird.setAvgLifeTime("5 years");
		 sparrowBird.setweight("0.515");
		 
		 displayBirdInformation(sparrowBird);
		 
		 sparrowBird.fly("Can fly 32km/h");
		 sparrowBird.walk("Can walk 1.5km/h");
		 
		 System.out.println("**********************************");
		 
		 Bird penguinBird=new Bird();
		 penguinBird.setname("penguin");
		 penguinBird.setclr("white-black");
		 penguinBird.setswim("Yes");
		 penguinBird.setAvgLifeTime("20 years");
		 penguinBird.setweight("100Kg");
		 
		 displayBirdInformation(penguinBird);
		 
		 penguinBird.fly("Cannot fly");
		 penguinBird.walk("Can walk 5 to 6 km/h");

	}
}
