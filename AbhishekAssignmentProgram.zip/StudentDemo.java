package javatraining;

 class Student
{
	 String name;
	 int age; 
 
	 void printInstanceVariable()
	 {
		 System.out.println("name : "+ name);
		 System.out.println("age : "+ age);
	 }
}

public class StudentDemo
{
	public static void main(String[] args)
	{
		Student stud1 = new Student();
		stud1.name = "Abhi";
		stud1.age = 25;
		
		Student stud2 = new Student();
		stud2.name = "Shrddha";
		stud2.age = 27;
		
		Student stud3 = new Student();
		stud3.name = "Avi";
		stud3.age = 23;
		
		
		stud1.printInstanceVariable();
		stud2.printInstanceVariable();
		stud3.printInstanceVariable();
	}
}