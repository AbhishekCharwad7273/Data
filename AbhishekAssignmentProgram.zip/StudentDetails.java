package javatraining;


import java.util.*;
 class Sinhgad
	{
	 private String name ;
	 private int rollno ;
	 private float marks ;
	 private char grade;
	 
	 public void readStudent()
	 {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter student name..");
		 name=sc.next();
		 System.out.println("Enter Student Roll no...");
		 rollno=sc.nextInt();
		 System.out.println("Enter Student marks...");
		 marks=sc.nextFloat();
	 
	 }
	 
	 public void calGrade()
	 {
		 if(marks>=75)
			 grade='O';
		 else if(marks>=60)
			 grade='A';
		 else if(marks>=50)
			 grade='B';
		 else if(marks>=40)
			 grade='C';
		 else
			 grade='F';
	 }
	 
	 void dispStudent()
	 {
		 calGrade();
		 System.out.println("---------------Studnet Information---------------");
		 System.out.println("Name: "+name);
		 System.out.println("Rollno: "+rollno);
		 System.out.println("Marks: "+marks);
		 System.out.println("Grade: "+grade);
		 System.out.println("--------------------------------------------------");
	 }
	 
	 public int getRollno()
	 {
		 return rollno;
	 }
	 
	 float getMarks()
	 {
	 		return marks;
	 }
}
	 




public class StudentDetails 
{
	public static void main(String[] args) 
	{
	
		Sinhgad btech=new Sinhgad[10];
		Scanner sc=new Scanner(System.in);
		int choice,rollno;
		int pos=-1;
		float highmarks=0.0f;
		
		for(int i=0;i<10;i++)
		{
			btech[i]=new Sinhgad();
			System.out.println("Enter Details of Student."+(i+1));
			btech[i].readStudent();
		}
		do
		{
			System.out.println("Main Menu...");
			System.out.println("1. Specific Student");
			System.out.println("2. Topper");
			System.out.println("3. Exit");
			System.out.println("Enter Your choice(1..3)");
			choice=sc.nextInt();
			
		switch(choice)
		{
			case 1:
				System.out.println("Enter Roll no of Student whose Details U Want to see.. ");
				rollno=sc.nextInt();
				for(int i=0;i<10;i++)
				{
					if(btech[i].getRollno()==rollno)
					{
						btech[i].dispStudent();
						break;
					}
				}
				break;
				
		case 2:
			for (int i=0;i<10;i++)
			{
				if(btech[i].getMarks()>highmarks)
				{
					pos=i;
					highmarks=btech[i].getMarks();
				}
			}
			btech[pos].dispStudent();
			break;
		
		
		case 3:
		break;
	}
		} while (choice>=1 && choice<3);
		}

}
