package javatraining;

class Stud
{
 String name;
 int age;
 String color;
 String sex;
 	public void eating(String string)
 	{
 		System.out.println(name + " "+ string);
 	}
 	public void drinking(String string)
 	{
 		System.out.println(name + " "+ string);
 	}
 	public void running(String string)
 	{
 		System.out.println(name + " "+ string);
 	}
}


public class StudentInfo 
{
	 public static void main(String[] args)
	 {
		 Stud stud1 = new Stud();
	
		 stud1.name = "sneha";
		 stud1.age = 12;
		 stud1.color = "white";
		 stud1.sex = "female";
		 displayStudentInformation(stud1);
	 
		 System.out.println("\nBehaviors");

		 stud1.eating("can eat more foods");
		 stud1.drinking("can drink more water");
		 stud1.running("can run fast");
	
		 Stud stud2 = new Stud();

		 stud2.name = "Raj";
		 stud2.age = 14;
		 stud2.color = "brown";
		 stud2.sex = "male";
		 displayStudentInformation(stud2);
	 
		 System.out.println("\nBehaviors");
	
	 
		 stud2.eating("can eat less foods");
		 stud2.drinking("can drink more water");
		 stud2.running("can run slow");
	 
		 Stud stud3 = new Stud();
	
		 stud3.name = "aishu";
		 stud3.age = 12;
		 stud3.color = "white";
		 stud3.sex = "female";
		 displayStudentInformation(stud3);
	 
		 System.out.println("\nBehaviors");
	
	 
		 stud3.eating("can eat less foods");
		 stud3.drinking("can drink less water");
		 stud3.running("can run fast");
	 
	 

	 
}
	 private static void displayStudentInformation(Stud student)
	 {
		 System.out.println("Attributes");
		 System.out.println("--------------");
		 System.out.println("Name : " + student.name);
		 System.out.println("Age : " + student.age);
		 System.out.println("Color : " + student.color);
		 System.out.println("sex : " + student.sex);
	 }
}

	


