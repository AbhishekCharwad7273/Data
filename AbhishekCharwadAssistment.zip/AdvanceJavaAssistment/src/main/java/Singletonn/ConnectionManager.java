package Singletonn;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionManager
{
	public static void main(String[] args)
	{

		//String update_query = "update books set emp='lenin and martin' where id= 1006"; //here sql exception will happend because of wrong c
		
		DBConnection dbConnection = DBConnection.getInstance();
		try {
			Connection connection =dbConnection.getConnection();
		 	Statement stmt =  connection.createStatement();
			String str = "select * from books";
    	  	System.out.println("The SQL statement is: " + str + "\n");
    	  	
    	  	//System.out.println("Executing Update query using executeUpdate method");//here it give an sql exception
    	  	//int return_rows = stmt.executeUpdate(update_query);
    	  	//System.out.println("No. of Affected Rows = "+ return_rows);
    	  	ResultSet rs = stmt.executeQuery(str);
    	  	int Count = 0;
        
    	  	while(rs.next())
    	  	{   
    	  		String id= rs.getString("id");  
    	  		String  title = rs.getString("title");  
    	  		String  author  = rs.getString("author");
    	  		Double price=rs.getDouble("price");
    	  		int qty =rs.getInt("qty");
    	  		System.out.println(id+ ", " + title + ", " + author + ","+ price + ","+qty);
    	  		++Count;
    	  	}
    	  	System.out.println("Total number of records = " + Count);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}


