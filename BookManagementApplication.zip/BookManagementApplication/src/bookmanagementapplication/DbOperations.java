/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookmanagementapplication;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author abhishekac
 */
public class DbOperations 
{
    static public boolean login( String email1,String password1)
    {
        boolean status=false;
        try
        {
         Connection con=DbConnection.getConnection();
         PreparedStatement ps=con.prepareStatement("select * from admin where email_id=? and password=?");

         ps.setString(1, email1);
         ps.setString(2, password1);

         ResultSet rs=ps.executeQuery();
         if(rs.next())
         {
             status=true;
         }
         else
         {
             status=false;
         }

          con.close();
          ps.close();
          rs.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return status;
    }   
}
