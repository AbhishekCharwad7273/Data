/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookmanagementapplication;

/**
 *
 * @author abhishekac
 */
public class RegisterModel 
{
    private String book_name;
     private String book_edition;
     private int book_price;

    /**
     * @return the book_name
     */
     public RegisterModel()
        {
            
        }
    public String getBook_name() {
        return book_name;
    }

    /**
     * @return the book_edition
     */
    public String getBook_edition() {
        return book_edition;
    }

    /**
     * @return the book_price
     */
    public int getBook_price() {
        return book_price;
    }

    /**
     * @param book_name the book_name to set
     */
    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    /**
     * @param book_edition the book_edition to set
     */
    public void setBook_edition(String book_edition) {
        this.book_edition = book_edition;
    }

    /**
     * @param book_price the book_price to set
     */
    public void setBook_price(int book_price) {
        this.book_price = book_price;
    }
    
}
