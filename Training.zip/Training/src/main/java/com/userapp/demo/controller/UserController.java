package com.userapp.demo.controller;

import com.userapp.demo.model.User;
import com.userapp.demo.model.UserDTO;
import com.userapp.demo.service.UserServiceImpl;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1")
public class UserController {

    @Autowired
    ModelMapper modelMapper;


    private final UserServiceImpl userService;

    UserController(UserServiceImpl userService) {
        this.userService = userService;
    }

    @GetMapping("/users/{name}")
    public ResponseEntity<User> getUserName(@PathVariable String name) {
        return new ResponseEntity<>(userService.getUserData(name), HttpStatus.OK);
    }

    @PostMapping("/users")
    public ResponseEntity<Integer> createUserName(@Valid @RequestBody UserDTO userDTO) {
        User user = convertToEntity(userDTO);
        return new ResponseEntity<>(userService.createUserData(user), HttpStatus.CREATED);
    }

    @PatchMapping("/users")
    public ResponseEntity<String> updateLastUserName(@RequestBody UserDTO userDTO) {
        User user = convertToEntity(userDTO);
        return new ResponseEntity<>(userService.updateUserData(user), HttpStatus.ACCEPTED);
    }

    private User convertToEntity(UserDTO userDTO) {
        return modelMapper.map(userDTO, User.class);

    }

}
