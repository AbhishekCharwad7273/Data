package com.userapp.demo.model;

import lombok.Data;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Data
public class UserDTO {
    @NotNull(message = "Name cannot be null")
    @Size(min = 3, max = 10)
    private String firstName;
    private String lastName;
    private String dob;
}
