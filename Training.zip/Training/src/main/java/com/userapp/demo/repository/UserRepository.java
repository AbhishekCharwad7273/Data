package com.userapp.demo.repository;


import com.userapp.demo.model.User;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

    Optional<User> findUserByFirstName(String name);

    @Modifying
    @Query("update User u set u.lastName = :lastName where u.id = :id")
    int updateUserLastName(@Param(value = "lastName") String lastName, @Param(value = "id") int id);

}
