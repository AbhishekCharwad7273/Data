package com.userapp.demo.service;

import com.userapp.demo.model.User;

public interface UserService {
    User getUserData(String name);

    int createUserData(User user);

    String updateUserData(User user);
}
