package com.userapp.demo.service;

import com.userapp.demo.exception.UserNotFoundException;
import com.userapp.demo.model.User;
import com.userapp.demo.repository.UserRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository repository;
    private static final String USERUPDATESUCCESS = "USER_UPDATE_SUCCESS";
    private static final String USERUPDATEFAILED = "USER_UPDATE_FAILED";
    private static final String USERNOTFOUND = "User not in system";

    UserServiceImpl(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public User getUserData(String name) {
        return repository.findUserByFirstName(name).orElseThrow(() -> new UserNotFoundException(USERNOTFOUND));
    }

    @Override
    public int createUserData(User user) {
        User createdUser = repository.save(user);
        return createdUser.getId();
    }

    @Override
    @Transactional
    public String updateUserData(User user) {
        User userDate = getUserData(user.getFirstName());


        int updatedUserStatus = repository.updateUserLastName(user.getLastName(), userDate.getId());
        if (updatedUserStatus == 1)
            return USERUPDATESUCCESS;
        else
            return USERUPDATEFAILED;
    }
}
