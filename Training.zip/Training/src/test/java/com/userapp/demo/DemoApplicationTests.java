package com.userapp.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

    @Test
    public void main() {
        DemoApplication.main(new String[]{});
    }

    @Test
    void contextLoads() {
    }

}
