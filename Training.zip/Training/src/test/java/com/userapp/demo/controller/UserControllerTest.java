package com.userapp.demo.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.userapp.demo.exception.UserNotFoundException;
import com.userapp.demo.model.User;
import com.userapp.demo.service.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.is;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(controllers = UserController.class)
class UserControllerTest {
    @Autowired
    MockMvc mockMvc;

    @MockBean
    UserServiceImpl userService;

    @Test
    void getUserByNameTest() throws Exception {
        User user = new User(1, "test", "test", "3-05-2007");
        given(userService.getUserData("test")).willReturn(user);
        mockMvc.perform(get("/api/v1/users/test")).andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.firstName", is("test")));
    }

    @Test
    void getUserByNameTestNotFoundExceptionTest() throws Exception {
        given(userService.getUserData("test")).willThrow(new UserNotFoundException("User not in system"));
        mockMvc.perform(get("/api/v1/users/test")).andExpect(status().isNotFound());
    }

    @Test
    void getUserByNameExTest() throws Exception {
        given(userService.getUserData("test")).willThrow(new RuntimeException());
        mockMvc.perform(get("/api/v1/users/test")).andExpect(status().isInternalServerError());
    }

    @Test
    void createUserTest() throws Exception {
        User user = new User(1, "test", "test", "03-05-2007");
        given(userService.createUserData(user)).willReturn(user.getId());
        mockMvc.perform(post("/api/v1/users/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new User(1, "two", "two", "30-06-1984"))))
                .andExpect(status().isCreated());

    }

    @Test
    void createUserTestInValidArgrument() throws Exception {
        mockMvc.perform(post("/api/v1/users/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new User(1, "tw", "two", "30-06-1984"))))
                .andExpect(status().isBadRequest());

    }


    @Test
    void updateUserTest() throws Exception {
        User user = new User(1, "test", "two", "30-05-2007");
        given(userService.updateUserData(user)).willReturn("USER_CREATED_SUCCESS");
        mockMvc.perform(patch("/api/v1/users/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new User(1, "one", "two", "30-06-1984"))))
                .andExpect(status().isAccepted());


    }

    private String asJsonString(Object obj) throws JsonProcessingException {
        return new ObjectMapper().writeValueAsString(obj);
    }
}
