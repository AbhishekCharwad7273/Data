package com.userapp.demo.repository;

import com.userapp.demo.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class UserRepositoryTest {

    @Autowired
    UserRepository repository;
    User createdUserA;
    User createdUserB;

    @BeforeEach
    void init() {
        User user1 = new User("five", "five", "20-08-1995");
        createdUserA = repository.save(user1);

        User user2 = new User("six", "six", "20-08-1995");
        createdUserB = repository.save(user2);
    }


    @Test
    void saveUserTest() {

        assertEquals("five", createdUserA.getFirstName());
        assertEquals(1, createdUserA.getId());
    }

    @Test
    void findUserByNameTest() {
        Optional<User> userData = repository.findUserByFirstName("six");

        assertEquals("six", userData.get().getFirstName());
        assertEquals(6, userData.get().getId());
    }

    @Test
    void updateUserByLastTest() {
        repository.updateUserLastName("updateLastName", 5);

        assertEquals("six", createdUserB.getLastName());
    }
}
