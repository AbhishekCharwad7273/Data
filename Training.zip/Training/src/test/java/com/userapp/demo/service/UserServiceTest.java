package com.userapp.demo.service;

import com.userapp.demo.exception.UserNotFoundException;
import com.userapp.demo.model.User;
import com.userapp.demo.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    UserRepository repository;

    private UserServiceImpl userService;

    @BeforeEach
    void init() {
        userService = new UserServiceImpl(repository);

    }

    @Test
    void getUserByNameTest() {
        given(repository.findUserByFirstName("test")).willReturn(java.util.Optional.of(new User(1, "test", "test", "30-05-1987")));
        User user = userService.getUserData("test");
        Assertions.assertEquals(1, user.getId());
        Assertions.assertEquals("test", user.getFirstName());
    }

    @Test
    void getUserByNameNotFoundTest() {
        given(repository.findUserByFirstName("test")).willThrow(new UserNotFoundException("User not in system"));
        Assertions.assertThrows(UserNotFoundException.class, () -> userService.getUserData("test"));
    }

    @Test
    void createUserTest() {
        given(repository.save(any(User.class))).willReturn(new User(3, "three", "three", "25-07-1992"));
        int userId = userService.createUserData(new User("three", "three", "25-07-1992"));
        Assertions.assertEquals(3, userId);
    }

    @Test
    void updateUserTest() {
        given(repository.findUserByFirstName("three")).willReturn(java.util.Optional.of(new User(15, "three", "four", "25-07-1992")));
        given(repository.updateUserLastName("five", 15)).willReturn(1);

        String updateStatus = userService.updateUserData(new User("three", "five", "25-07-1992"));
        Assertions.assertEquals("USER_UPDATE_SUCCESS", updateStatus);
    }

    @Test
    void updateUserFailTest() {
        given(repository.findUserByFirstName("three")).willReturn(java.util.Optional.of(new User(15, "three", "four", "25-07-1992")));
        given(repository.updateUserLastName("five", 15)).willReturn(-1);

        String updateStatus = userService.updateUserData(new User("three", "five", "25-07-1992"));
        Assertions.assertEquals("USER_UPDATE_FAILED", updateStatus);
    }
}
