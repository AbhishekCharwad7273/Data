package com.mavericbankapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavericbankappApplicationTests {

	@Test
	void contextLoads() {
	}

}
