package com.maveric.usercreation.controller;

import com.maveric.usercreation.model.User;
import com.maveric.usercreation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService service;

    @PostMapping("/users")
    public List <User> addUser(@RequestBody List<User> user)
    {
        return service.saveUser(user);
    }

    @GetMapping("/getuser")
    public List<User> listAlluser()
    {
        return service.getuser();
    }
    @GetMapping("/user/{id}")
    public User findUserById(@PathVariable int Id)
    {
        return service.getUserById(Id);
    }

    @PutMapping("/update")
    public User updateUser(@RequestBody User user)
    {
        return service.updateUserByID(user);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteProduct(@PathVariable int Id)
    {
        return service.deleteProductById(Id);
    }
}
