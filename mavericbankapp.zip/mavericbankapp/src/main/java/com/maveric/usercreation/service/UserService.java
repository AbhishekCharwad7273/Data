package com.maveric.usercreation.service;

import com.maveric.usercreation.model.User;
import com.maveric.usercreation.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository repository;

    public List<User> saveUser(List<User> user)
    {
        return repository.saveAll(user);

    }

    public List<User> getuser()
    {
        return repository.findAll();
    }

    public User getUserById(int Id)
    {
        return repository.findById(Id).orElse(null);
    }


    public String deleteProductById(int Id)
    {
        repository.deleteById(Id);
        return "User Removed..!!1"+Id;
    }
    public User updateUserByID(User user)
    {
        User existingUser=repository.findById(user.getId()).orElse(null);
        existingUser.setFirstName(user.getFirstName());
        existingUser.setMiddleName(user.getMiddleName());
        existingUser.setLastName(user.getLastName());
        existingUser.setEmail(user.getEmail());
        existingUser.setAddress(user.getAddress());
        existingUser.setDateOfBirth(user.getDateOfBirth());
        existingUser.setGender(user.getGender());
        existingUser.setPhoneNumber(user.getPhoneNumber());
        existingUser.setPassword(user.getPassword());
        return repository.save(existingUser);




    }

}
